# NUR 175 Study Guide — Website

Two files:
- `index.html` — the whole study guide (must keep this exact name)
- `background.jpg` — the neon-heart background (must sit next to index.html)

## Put it on GitHub Pages (once, ~5 minutes)

1. Go to **github.com** → sign in (or Sign up, it's free).
2. Top-right **+** → **New repository**.
3. Repository name: `nur175-study-guide` (lowercase, no spaces). Leave it **Public**. Click **Create repository**.
4. On the new repo page, click the **"uploading an existing file"** link.
5. Drag in **index.html** and **background.jpg** (both files from this zip — unzip it first).
6. Click the green **Commit changes** button.
7. Go to **Settings** (tab at the top of the repo) → **Pages** (left sidebar).
8. Under **Build and deployment** → Source: **Deploy from a branch** → Branch: **main**, folder **/ (root)** → **Save**.
9. Wait 1–2 minutes, refresh the Pages screen — your link appears at the top:
   `https://YOUR-USERNAME.github.io/nur175-study-guide/`
10. Open it on your phone, bookmark it. Done.

## To update the guide later
Repo page → click `index.html` → pencil icon is NOT needed — instead click **Add file → Upload files**, drag the new `index.html`, **Commit changes**. The site updates itself in ~1 minute.

## Heads up
The site is **public** — anyone with the link can view it. Don't put personal info in the guide.
